﻿namespace sehirUzaklıgı
{
    //Kayseri merkez olacak
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"C:\şehirUzaklığı\";
            Directory.CreateDirectory(path);
            Dictionary<double, string> sehirler = new Dictionary<double, string>();
            sehirler.Add(306.3, "Adana");
            sehirler.Add(308, "Adıyaman");
            sehirler.Add(543.1, "Afyon");
            sehirler.Add(812.5, "Ağrı");
            sehirler.Add(326.3, "Amasya");
            sehirler.Add(343.3, "Ankara");
            sehirler.Add(819.2, "Artvin");
            sehirler.Add(796.4, "Aydın");
            sehirler.Add(815.9, "Balıkesir");
            sehirler.Add(598.9, "Bilecik");
            sehirler.Add(569.4, "Bingöl");
            sehirler.Add(760.7, "Bitlis");
            sehirler.Add(521.7, "Bolu");
            sehirler.Add(571.8, "Burdur");
            sehirler.Add(669.9, "Bursa");
            sehirler.Add(1090.7, "Çanakkale");
            sehirler.Add(350, "Çankırı");
            sehirler.Add(281.9, "Çorum");
            sehirler.Add(676, "Denizli");
            sehirler.Add(561.8, "Diyarbakır");
            sehirler.Add(1022.2, "Edirne");
            sehirler.Add(434.2, "Elâzığ");
            sehirler.Add(440.7, "Erzincan");
            sehirler.Add(631.7, "Erzurum");
            sehirler.Add(518.2, "Eskişehir ");
            sehirler.Add(329.6, "Gaziantep ");
            sehirler.Add(473, "Giresun ");
            sehirler.Add(515.8, "Gümüşhane ");
            sehirler.Add(1018.3, "Hakkâri ");
            sehirler.Add(399.5, "Hatay ");
            sehirler.Add(541.7, "Isparta ");
            sehirler.Add(314.8, "Mersin ");
            sehirler.Add(780.2, "İstanbul ");
            sehirler.Add(871.6, "İzmir ");
            sehirler.Add(833.6, "Kars ");
            sehirler.Add(456.5, "Kastamonu ");
            sehirler.Add(996.3, "Kırklareli ");
            sehirler.Add(137.9, "Kırşehir ");
            sehirler.Add(680.1, "Kocaeli ");
            sehirler.Add(302.3, "Konya ");
            sehirler.Add(597.8, "Kütahya ");
            sehirler.Add(334.5, "Malatya ");
            sehirler.Add(844.2, "Manisa ");
            sehirler.Add(254, "Kahramanmaraş ");
            sehirler.Add(663.5, "Mardin ");
            sehirler.Add(803, "Muğla ");
            sehirler.Add(680.3, "Muş ");
            sehirler.Add(80.5, "Nevşehir ");
            sehirler.Add(131.8, "Niğde ");
            sehirler.Add(452.1, "Ordu ");
            sehirler.Add(648.9, "Rize ");
            sehirler.Add(654.2, "Sakarya ");
            sehirler.Add(450.2, "Samsun ");
            sehirler.Add(753.2, "Siirt ");
            sehirler.Add(546.5, "Sinop ");
            sehirler.Add(169.9, "Sivas ");
            sehirler.Add(929.2, "Tekirdağ ");
            sehirler.Add(261.8, "Tokat ");
            sehirler.Add(578.7, "Trabzon ");
            sehirler.Add(531.5, "Tunceli ");
            sehirler.Add(476.9, "Şanlıurfa ");
            sehirler.Add(652.4, "Uşak ");
            sehirler.Add(894.2, "Van ");
            sehirler.Add(179.4, "Yozgat ");
            sehirler.Add(607.3, "Zonguldak ");
            sehirler.Add(155.5, "Aksaray ");
            sehirler.Add(545, "Bayburt ");
            sehirler.Add(315.1, "Karaman ");
            sehirler.Add(245.8, "Kırıkkale ");
            sehirler.Add(670.5, "Batman ");
            sehirler.Add(828.6, "Şırnak ");
            sehirler.Add(624.1, "Bartın ");
            sehirler.Add(853.7, "Ardahan ");
            sehirler.Add(955.2, "Iğdır ");
            sehirler.Add(759.7, "Yalova ");
            sehirler.Add(552.9, "Karabük ");
            sehirler.Add(388.6, "Kilis ");
            sehirler.Add(395.4, "Osmaniye ");
            sehirler.Add(570.5, "Düzce ");
            sehirler.Add(0, "Kayseri ");
            using (StreamWriter sw = File.CreateText(path + "şehirUzaklıkları.txt"))
            {

                foreach (var item in sehirler)
                {
                    sw.Write(item.Value+" "+item.Key+"!");
                }
            }

        }
    }
}